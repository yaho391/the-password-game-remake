document.addEventListener('DOMContentLoaded', () => {
    const tabBtns = document.querySelectorAll('.tab-btn');
    const tabContents = document.querySelectorAll('.tab-content');

    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const target = btn.getAttribute('data-tab');

            tabBtns.forEach(b => b.classList.remove('active'));
            tabContents.forEach(c => c.classList.remove('active'));

            btn.classList.add('active');
            const content = document.getElementById(target);
            if (content) content.classList.add('active');
        });
    });

    const registerForm = document.getElementById('register-form');
    const loginForm = document.getElementById('login-form');

    function showError(input, message) {
        const group = input.closest('.form-group');
        if (!group) return;
        const error = group.querySelector('.error-message');
        if (!error) return;
        error.textContent = message;
        error.style.display = message ? 'block' : 'none';
        if (message) {
            input.classList.add('input-error');
        } else {
            input.classList.remove('input-error');
        }
    }

    function clearErrors(form) {
        form.querySelectorAll('.error-message').forEach(e => {
            e.textContent = '';
            e.style.display = 'none';
        });
        form.querySelectorAll('.input-error').forEach(i => i.classList.remove('input-error'));
    }

    function validatePassword(pw) {
        const errors = [];
        if (pw.length < 8) errors.push('Пароль должен быть не короче 8 символов.');
        if (!/[A-ZА-ЯЁ]/.test(pw)) errors.push('Добавьте хотя бы одну заглавную букву.');
        if (!/[a-zа-яё]/.test(pw)) errors.push('Добавьте хотя бы одну строчную букву.');
        if (!/\d/.test(pw)) errors.push('Добавьте хотя бы одну цифру.');
        if (!/[^A-Za-zА-Яа-яЁё0-9\s]/.test(pw)) errors.push('Добавьте хотя бы один специальный символ.');
        return errors;
    }

    function loadUsers() {
        const raw = localStorage.getItem('users');
        if (!raw) return {};
        try {
            return JSON.parse(raw);
        } catch {
            return {};
        }
    }

    function saveUsers(users) {
        localStorage.setItem('users', JSON.stringify(users));
    }

    if (registerForm) {
        registerForm.addEventListener('submit', (e) => {
            e.preventDefault();
            clearErrors(registerForm);

            const username = document.getElementById('reg-username');
            const email = document.getElementById('reg-email');
            const password = document.getElementById('reg-password');
            const confirm = document.getElementById('reg-confirm');

            let valid = true;

            if (!username.value.trim()) {
                showError(username, 'Введите имя пользователя.');
                valid = false;
            }

            if (!email.value.trim()) {
                showError(email, 'Введите e-mail.');
                valid = false;
            } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value.trim())) {
                showError(email, 'Введите корректный e-mail.');
                valid = false;
            }

            const pwErrors = validatePassword(password.value);
            if (pwErrors.length > 0) {
                showError(password, pwErrors[0]);
                valid = false;
            }

            if (password.value !== confirm.value) {
                showError(confirm, 'Пароли не совпадают.');
                valid = false;
            }

            if (!valid) return;

            const users = loadUsers();
            if (users[username.value]) {
                showError(username, 'Пользователь с таким именем уже существует.');
                return;
            }

            users[username.value] = {
                username: username.value,
                email: email.value,
                password: password.value, 
            };
            saveUsers(users);

            localStorage.setItem('currentUser', JSON.stringify({
                username: username.value,
                email: email.value,
            }));

            window.location.href = 'index.html';
        });
    }

    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            clearErrors(loginForm);

            const username = document.getElementById('login-username');
            const password = document.getElementById('login-password');

            let valid = true;

            if (!username.value.trim()) {
                showError(username, 'Введите имя пользователя.');
                valid = false;
            }

            if (!password.value) {
                showError(password, 'Введите пароль.');
                valid = false;
            }

            if (!valid) return;

            const users = loadUsers();
            const user = users[username.value];
            if (!user || user.password !== password.value) {
                showError(password, 'Неверное имя пользователя или пароль.');
                return;
            }

            localStorage.setItem('currentUser', JSON.stringify({
                username: user.username,
                email: user.email,
            }));

            window.location.href = 'index.html';
        });
    }

    // Переключение показа пароля
    document.querySelectorAll(".toggle-pass").forEach(btn => {
    btn.addEventListener("click", () => {
        const target = document.getElementById(btn.dataset.target);
        if (target.type === "password") {
            target.type = "text";
            btn.textContent = "🙈";
        } else {
            target.type = "password";
            btn.textContent = "👁";
        }
    });
});

});
