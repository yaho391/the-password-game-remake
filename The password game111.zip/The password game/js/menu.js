document.addEventListener('DOMContentLoaded', () => {
    const usernameSpan = document.getElementById('menu-username');
    const playBtn = document.getElementById('play-btn');
    const recordsBtn = document.getElementById('records-btn');
    const logoutBtn = document.getElementById('logout-btn');
    const difficultySection = document.getElementById('difficulty-section');
    const recordsSection = document.getElementById('records-section');
    const startGameBtn = document.getElementById('start-game-btn');

    const recordEls = {
        easy: document.getElementById('record-easy'),
        medium: document.getElementById('record-medium'),
        hard: document.getElementById('record-hard'),
    };

    // Проверяем, что пользователь авторизован
    const currentUserRaw = localStorage.getItem('currentUser');
    if (!currentUserRaw) {
        window.location.href = 'reg.html';
        return;
    }

    let currentUser;
    try {
        currentUser = JSON.parse(currentUserRaw);
    } catch {
        currentUser = null;
    }

    if (!currentUser || !currentUser.username) {
        window.location.href = 'reg.html';
        return;
    }

    usernameSpan.textContent = currentUser.username;

    function formatTime(seconds) {
        const s = Math.floor(seconds % 60);
        const m = Math.floor(seconds / 60);
        const mm = String(m).padStart(2, '0');
        const ss = String(s).padStart(2, '0');
        return mm + ':' + ss;
    }

    function loadRecords() {
        const raw = localStorage.getItem('passwordGameRecords');
        let records = {};
        if (raw) {
            try {
                records = JSON.parse(raw);
            } catch {
                records = {};
            }
        }

        ['easy', 'medium', 'hard'].forEach(level => {
            const rec = records[level];
            if (rec && typeof rec.time === 'number') {
                recordEls[level].textContent = formatTime(rec.time);
            } else if (typeof rec === 'number') {
                recordEls[level].textContent = formatTime(rec);
            } else {
                recordEls[level].textContent = '—';
            }
        });
    }

    playBtn.addEventListener('click', () => {
        difficultySection.classList.remove('hidden');
        recordsSection.classList.add('hidden');
    });

    recordsBtn.addEventListener('click', () => {
        difficultySection.classList.add('hidden');
        recordsSection.classList.remove('hidden');
        loadRecords();
    });

    startGameBtn.addEventListener('click', () => {
        const checked = document.querySelector('input[name="difficulty"]:checked');
        if (!checked) {
            alert('Выберите уровень сложности');
            return;
        }
        const difficulty = checked.value;
        localStorage.setItem('currentDifficulty', difficulty);
        window.location.href = 'game.html';
    });

    logoutBtn.addEventListener('click', () => {
        localStorage.removeItem('currentUser');
        window.location.href = 'reg.html';
    });

    // При заходе сразу подгружаем рекорды в фоновом режиме
    loadRecords();
});
