document.addEventListener('DOMContentLoaded', () => {
    const userRaw = localStorage.getItem('currentUser');
    if (!userRaw) {
        window.location.href = 'reg.html';
        return;
    }

    let user;
    try {
        user = JSON.parse(userRaw);
    } catch {
        user = null;
    }
    if (!user || !user.username) {
        window.location.href = 'reg.html';
        return;
    }

    const difficulty = localStorage.getItem('currentDifficulty') || 'easy';

    const usernameEl = document.getElementById('game-username');
    const difficultyLabelEl = document.getElementById('game-difficulty-label');
    const timerEl = document.getElementById('game-timer');
    const passwordInput = document.getElementById('game-password');
    const rulesListEl = document.getElementById('game-rules');
    const statusEl = document.getElementById('game-status');
    const backBtn = document.getElementById('back-to-menu-btn');

    usernameEl.textContent = user.username;

    const difficultyNames = {
        easy: 'Лёгкий',
        medium: 'Средний',
        hard: 'Сложный',
    };
    difficultyLabelEl.textContent = difficultyNames[difficulty] || 'Лёгкий';

    // Вспомогательные функции
    const hasLower = s => /[a-zа-яё]/.test(s);
    const hasUpper = s => /[A-ZА-ЯЁ]/.test(s);
    const hasDigit = s => /\d/.test(s);
    const hasSpecial = s => /[^A-Za-zА-Яа-яЁё0-9\s]/.test(s);

    function getWordOfDay() {
        const words = ['apple', 'stone', 'brain', 'light', 'sound', 'world', 'pixel', 'logic', 'cloud'];
        const dayIndex = Math.floor(Date.now() / (1000 * 60 * 60 * 24));
        return words[dayIndex % words.length];
    }

    const wordOfDay = getWordOfDay();

    function buildRules(diff) {
        const baseEasy = [
            {
                id: 'len-8',
                text: 'Длина пароля не менее 8 символов.',
                check: pw => pw.length >= 8,
            },
            {
                id: 'has-digit',
                text: 'Содержит хотя бы одну цифру.',
                check: pw => hasDigit(pw),
            },
            {
                id: 'has-upper',
                text: 'Содержит хотя бы одну заглавную букву.',
                check: pw => hasUpper(pw),
            },
        ];

        const extraMedium = [
            {
                id: 'has-lower',
                text: 'Содержит хотя бы одну строчную букву.',
                check: pw => hasLower(pw),
            },
            {
                id: 'has-special',
                text: 'Содержит хотя бы один спецсимвол (например, !, @, #, $, %).',
                check: pw => hasSpecial(pw),
            },
            {
                id: 'word-of-day',
                text: 'Содержит слово дня из Wordle: "' + wordOfDay.toUpperCase() + '".',
                check: pw => pw.toLowerCase().includes(wordOfDay.toLowerCase()),
            },
        ];

        const extraHard = [
            {
                id: 'len-16',
                text: 'Длина пароля не менее 16 символов.',
                check: pw => pw.length >= 16,
            },
            {
                id: 'no-password',
                text: 'Не содержит слово "password" в любом регистре.',
                check: pw => !/password/i.test(pw),
            },
            {
                id: 'three-types',
                text: 'Используются минимум три разных типа символов (строчные, заглавные, цифры, спецсимволы).',
                check: pw => {
                    let types = 0;
                    if (hasLower(pw)) types++;
                    if (hasUpper(pw)) types++;
                    if (hasDigit(pw)) types++;
                    if (hasSpecial(pw)) types++;
                    return types >= 3;
                },
            },
        ];

        if (diff === 'easy') return baseEasy;
        if (diff === 'medium') return baseEasy.concat(extraMedium);
        if (diff === 'hard') return baseEasy.concat(extraMedium).concat(extraHard);
        return baseEasy;
    }

    const rules = buildRules(difficulty);

    // Отрисуем правила
    const ruleState = new Map();
    rulesListEl.innerHTML = '';
    rules.forEach(rule => {
        const li = document.createElement('li');
        li.dataset.ruleId = rule.id;
        li.className = 'rule-item rule-pending';
        li.innerHTML = '<span class="rule-indicator"></span><span class="rule-text">' + rule.text + '</span>';
        rulesListEl.appendChild(li);
        ruleState.set(rule.id, false);
    });

    let timerStarted = false;
    let startTime = null;
    let timerInterval = null;
    let finished = false;

    function formatTime(ms) {
        const totalSeconds = Math.floor(ms / 1000);
        const s = totalSeconds % 60;
        const m = Math.floor(totalSeconds / 60);
        const mm = String(m).padStart(2, '0');
        const ss = String(s).padStart(2, '0');
        return { label: mm + ':' + ss, seconds: totalSeconds };
    }

    function startTimer() {
        if (timerStarted) return;
        timerStarted = true;
        startTime = performance.now();
        timerInterval = setInterval(() => {
            const now = performance.now();
            const diff = now - startTime;
            const t = formatTime(diff);
            timerEl.textContent = t.label;
        }, 200);
    }

    function stopTimer() {
        if (!timerStarted) return;
        clearInterval(timerInterval);
        timerInterval = null;
    }

    function updateRules() {
        const pw = passwordInput.value || '';

        if (!timerStarted && pw.length > 0) {
            startTimer();
        }

        let allPass = true;
        rules.forEach(rule => {
            const pass = !!rule.check(pw);
            ruleState.set(rule.id, pass);
            const li = rulesListEl.querySelector('li[data-rule-id="' + rule.id + '"]');
            if (!li) return;
            li.classList.remove('rule-pass', 'rule-fail', 'rule-pending');
            if (pw.length === 0) {
                li.classList.add('rule-pending');
            } else if (pass) {
                li.classList.add('rule-pass');
            } else {
                li.classList.add('rule-fail');
                allPass = false;
            }
        });

        if (pw.length === 0) {
            statusEl.textContent = 'Начните вводить пароль.';
            return;
        }

        if (allPass) {
            if (!finished) {
                finished = true;
                stopTimer();
                const now = performance.now();
                const diff = now - startTime;
                const t = formatTime(diff);

                statusEl.textContent = 'Поздравляем! Все правила выполнены. Ваше время: ' + t.label;

                // Обновляем рекорды
                const raw = localStorage.getItem('passwordGameRecords');
                let records = {};
                if (raw) {
                    try {
                        records = JSON.parse(raw);
                    } catch {
                        records = {};
                    }
                }
                const existing = records[difficulty];
                if (!existing || (existing.time && existing.time > t.seconds) || (typeof existing === 'number' && existing > t.seconds)) {
                    records[difficulty] = { time: t.seconds, username: user.username, date: new Date().toISOString() };
                    localStorage.setItem('passwordGameRecords', JSON.stringify(records));
                    alert('Новый рекорд на уровне "' + difficultyNames[difficulty] + '": ' + t.label + '!');
                } else {
                    alert('Игра пройдена за ' + t.label + '. Рекорд для этого уровня: ' + (existing.time ? formatTime(existing.time * 1000).label : formatTime(existing * 1000).label));
                }
            }
        } else {
            finished = false;
            statusEl.textContent = 'Выполните все правила, чтобы закончить игру.';
        }
    }

    passwordInput.addEventListener('input', updateRules);

    backBtn.addEventListener('click', () => {
        window.location.href = 'index.html';
    });

    // Инициализация
    statusEl.textContent = 'Начните вводить пароль. Постепенно выполняйте правила.';
    timerEl.textContent = '00:00';
});
